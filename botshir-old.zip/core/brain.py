import numpy as np
import os
import pickle

class MarsBrain:
    def __init__(self, cfg):
        self.cfg = cfg
        self.model_path = cfg['paths']['mars_model']
        self.old_path = cfg['paths']['old_model']
        self.hidden_size = cfg['brain']['hidden_size']
        self.w2i, self.i2w = {}, {}
        
        # Kiến trúc: W_in -> W_h (+ b_h) -> (ReLU) -> W_out (+ b_out)
        self.W_in = None
        self.W_h = None
        self.b_h = None
        self.W_out = None
        self.b_out = None
        
        self.tfidf = {}
        self.load_model()

    def load_model(self):
        path = self.model_path if os.path.exists(self.model_path) else self.old_path
        if os.path.exists(path):
            try:
                with open(path, "rb") as f:
                    data = pickle.load(f)
                    self.W_in = data["W_in"]
                    self.W_h = data["W_h"]
                    self.b_h = data["b_h"]
                    self.W_out = data["W_out"]
                    self.b_out = data["b_out"]
                    self.w2i, self.i2w = data["w2i"], data["i2w"]
                    self.tfidf = data.get("tfidf", {})
                    
                    if self.W_in.shape[1] != self.hidden_size:
                        self.init_empty()
            except: self.init_empty()
        else: self.init_empty()

    def init_empty(self):
        self.W_in = np.empty((0, self.hidden_size), dtype=np.float32)
        self.W_h = np.empty((self.hidden_size, self.hidden_size), dtype=np.float32)
        self.b_h = np.zeros((1, self.hidden_size), dtype=np.float32)
        self.W_out = np.empty((self.hidden_size, 0), dtype=np.float32)
        self.b_out = np.empty((1, 0), dtype=np.float32)
        self.w2i, self.i2w = {}, {}
        self.tfidf = {}

    def expand(self, words):
        new = [w for w in words if w not in self.w2i]
        if not new: return
        curr = len(self.w2i)
        for i, w in enumerate(new):
            self.w2i[w], self.i2w[curr + i] = curr + i, w
        
        std = self.cfg['brain']['init_std']
        
        # New Input weights
        e_in = (np.random.randn(len(new), self.hidden_size) * std).astype(np.float32)
        self.W_in = np.vstack([self.W_in, e_in]) if self.W_in.size else e_in
        
        # Hidden weights & bias
        if not self.W_h.any():
            self.W_h = (np.random.randn(self.hidden_size, self.hidden_size) * std).astype(np.float32)
            self.b_h = np.zeros((1, self.hidden_size), dtype=np.float32)
            
        # New Output weights & bias
        e_out = (np.random.randn(self.hidden_size, len(new)) * std).astype(np.float32)
        self.W_out = np.hstack([self.W_out, e_out]) if self.W_out.size else e_out
        
        e_b_out = np.zeros((1, len(new)), dtype=np.float32)
        self.b_out = np.hstack([self.b_out, e_b_out]) if self.b_out.size else e_b_out

    def save(self):
        with open(self.model_path, "wb") as f:
            pickle.dump({
                "W_in": self.W_in, "W_h": self.W_h, "b_h": self.b_h,
                "W_out": self.W_out, "b_out": self.b_out,
                "w2i": self.w2i, "i2w": self.i2w, 
                "tfidf": self.tfidf
            }, f)
