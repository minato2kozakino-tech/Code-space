import numpy as np
import os
import sys
import time
from collections import Counter

def relu(x):
    return np.maximum(0, x)

def relu_derivative(x):
    return (x > 0).astype(np.float32)

def train_mars(brain, cfg):
    data_file = cfg['paths']['data_file']
    epochs = cfg['trainer']['epochs']
    lr = cfg['trainer']['learning_rate']
    n_gram = cfg['trainer']['n_gram']

    if not os.path.exists(data_file):
        print(f"[-] Data file {data_file} not found.")
        return
    
    print("[+] Loading tokens...")
    with open(data_file, "r", encoding="utf-8") as f:
        tokens = f.read().lower().split()
    
    counts = Counter(tokens)
    total = len(tokens)
    brain.tfidf = {w: np.log(total/(c+1)) for w, c in counts.items()}
    
    brain.expand(list(set(tokens)))
    token_ids = np.array([brain.w2i[t] for t in tokens], dtype=np.uint32)
    n_samples = len(token_ids) - n_gram
    if n_samples <= 0: return

    print(f"[+] Training Deep Mars with Bias ({epochs} Epochs)...")
    for ep in range(1, epochs + 1):
        start = time.time()
        indices = np.arange(n_samples)
        np.random.shuffle(indices)
        
        for i, idx in enumerate(indices):
            if i % 500 == 0 or i == n_samples - 1:
                pct = (i + 1) / n_samples
                bar = "#" * int(15 * pct) + "-" * (15 - int(15 * pct))
                sys.stdout.write(f"\rEpoch {ep:02d}/{epochs} |{bar}| {pct:>4.1%}")
                sys.stdout.flush()
                
            ctx = token_ids[idx : idx + n_gram]
            target = token_ids[idx + n_gram]
            
            # Forward Pass
            h1 = np.mean(brain.W_in[ctx], axis=0).reshape(1, -1)
            z2 = np.dot(h1, brain.W_h) + brain.b_h
            h2 = relu(z2)
            logits = np.dot(h2, brain.W_out) + brain.b_out
            
            # Softmax
            probs = np.exp(logits - np.max(logits))
            probs /= np.sum(probs)
            
            # Backward Pass
            d_logits = probs.copy()
            d_logits[0, target] -= 1
            
            # d_W_out, d_b_out, d_h2
            d_W_out = np.dot(h2.T, d_logits)
            d_b_out = d_logits
            d_h2 = np.dot(d_logits, brain.W_out.T)
            
            # d_z2
            d_z2 = d_h2 * relu_derivative(z2)
            
            # d_W_h, d_b_h, d_h1
            d_W_h = np.dot(h1.T, d_z2)
            d_b_h = d_z2
            d_h1 = np.dot(d_z2, brain.W_h.T)
            
            # Clip Gradients (Simple)
            for grad in [d_W_out, d_b_out, d_W_h, d_b_h, d_h1]:
                np.clip(grad, -1.0, 1.0, out=grad)

            # Update weights & biases
            brain.W_out -= lr * d_W_out
            brain.b_out -= lr * d_b_out
            brain.W_h -= lr * d_W_h
            brain.b_h -= lr * d_b_h
            brain.W_in[ctx] -= lr * d_h1 / n_gram
            
        print(f" | Done {time.time()-start:.1f}s")
    
    brain.save()
    print("[!] Model with Bias saved.")
