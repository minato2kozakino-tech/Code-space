import json
import os
import random

class GrammarMars:
    def __init__(self, cfg):
        self.cfg = cfg
        self.db_path_en = cfg['paths']['db_config'] # en_data.json
        self.db_path_vn = cfg['paths']['db_config_vn'] # vn_data.json
        
        self.db_en = self._load_db(self.db_path_en)
        self.db_vn = self._load_db(self.db_path_vn)

    def _load_db(self, path):
        full_path = os.path.join(os.path.dirname(__file__), "..", path)
        with open(full_path, "r", encoding="utf-8") as f:
            return json.load(f)

    def get(self, key, lang='en'): 
        db = self.db_en if lang == 'en' else self.db_vn
        return random.choice(db.get(key, ['unknown']))

    # --- ENGLISH GRAMMAR PATTERNS ---
    def en_simple(self): return f"{self.get('subject')} {self.get('verb')} {self.get('object')}"
    def en_opinion(self): return f"{self.get('subject')} {self.get('verb')} that {self.get('object')} is {self.get('adjective')}"
    def en_offer(self): return f"if {self.get('subject')} {self.get('verb')} {self.get('object')} , {self.get('subject')} {self.get('modal')} {self.get('verb')} {self.get('object')}"
    def en_complex_action(self): return f"{self.get('subject')} {self.get('modal')} {self.get('verb')} the {self.get('object')} {self.get('adverb')}"
    def en_conversation(self): return f"{self.get('filler')} , {self.get('subject')} {self.get('adverb')} {self.get('verb')} {self.get('preposition')} {self.get('object')}"
    def en_critical(self): return f"{self.get('subject')} {self.get('past')} {self.get('verb')} {self.get('object')}"
    def en_tech_context(self): return f"{self.get('subject')} {self.get('verb')} {self.get('tech_term')} {self.get('adverb')}"
    def en_interaction(self): return f"{self.get('greetingword')} , {self.get('firstquestion')}"
    def en_python_code(self): return f"{self.get('python_code')}"
    def en_exclamation(self): return f"{self.get('exclamation')}"

    # --- VIETNAMESE GRAMMAR PATTERNS (NÂNG CẤP) ---
    def vn_simple(self): return f"{self.get('subject_vn', 'vn')} {self.get('verb_vn', 'vn')} {self.get('object_vn', 'vn')}"
    def vn_adjective(self): return f"{self.get('subject_vn', 'vn')} {self.get('tobe_vn', 'vn')} {self.get('adjective_vn', 'vn')}"
    def vn_complex(self): return f"{self.get('subject_vn', 'vn')} {self.get('verb_vn', 'vn')} {self.get('object_vn', 'vn')} {self.get('adverb_vn', 'vn')}"
    def vn_question(self): return f"{self.get('greeting_vn', 'vn')} , {self.get('firstquestion_vn', 'vn')}"
    def vn_opinion(self): return f"{self.get('subject_vn', 'vn')} {self.get('filler_vn', 'vn')} {self.get('verb_vn', 'vn')} rằng {self.get('object_vn', 'vn')} {self.get('tobe_vn', 'vn')} {self.get('adjective_vn', 'vn')}"
    def vn_conditional(self): return f"nếu {self.get('subject_vn', 'vn')} {self.get('verb_vn', 'vn')} {self.get('object_vn', 'vn')} thì {self.get('subject_vn', 'vn')} {self.get('modal_vn', 'vn')} {self.get('verb_vn', 'vn')} {self.get('adverb_vn', 'vn')}"
    def vn_tech(self): return f"{self.get('subject_vn', 'vn')} {self.get('modal_vn', 'vn')} {self.get('verb_vn', 'vn')} {self.get('tech_term_vn', 'vn')} một cách {self.get('adjective_vn', 'vn')}"
    def vn_interaction_deep(self): return f"{self.get('interaction_vn', 'vn')} , {self.get('filler_vn', 'vn')} {self.get('subject_vn', 'vn')} {self.get('verb_vn', 'vn')} {self.get('object_vn', 'vn')}"

    def build(self, lang='en', size_kb=2000):
        data_file = self.cfg['paths']['data_file']
        target_bytes = size_kb * 1024
        print(f"[+] Generating {lang.upper()} Dataset for Origon AI ({size_kb}KB)...")
        
        if lang == 'en':
            patterns = [
                self.en_simple, self.en_opinion, self.en_offer, self.en_complex_action, 
                self.en_conversation, self.en_critical, self.en_tech_context, 
                self.en_interaction, self.en_python_code, self.en_exclamation
            ]
        elif lang == 'vn':
            patterns = [
                self.vn_simple, self.vn_adjective, self.vn_complex, self.vn_question,
                self.vn_opinion, self.vn_conditional, self.vn_tech, self.vn_interaction_deep
            ]
        else: return # Default to English or raise error

        with open(data_file, "w", encoding="utf-8") as f:
            curr_size = 0
            while curr_size < target_bytes:
                sentence = random.choice(patterns)()
                line_to_write = sentence + " ." + os.linesep
                f.write(line_to_write)
                curr_size += len(line_to_write.encode('utf-8'))
        print(f"[!] Dataset generation complete at {data_file}.")
