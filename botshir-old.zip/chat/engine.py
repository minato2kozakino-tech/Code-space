import numpy as np
from collections import Counter

def relu(x):
    return np.maximum(0, x)

def mars_generate(brain, words, cfg):
    max_len = cfg['chat']['max_len']
    temp = cfg['chat']['temperature']
    top_p = cfg['chat']['top_p']
    pen_base = cfg['chat']['repetition_penalty']['base']
    pen_inc = cfg['chat']['repetition_penalty']['incremental']
    context_window = cfg['chat']['context_window']

    ctx_words = words[-context_window:]
    ids = [brain.w2i[w] for w in ctx_words if w in brain.w2i]
    
    if not ids or brain.W_in.size == 0:
        return "..."
    
    res_text = []
    generated_ids = []
    
    for _ in range(max_len):
        # Forward Pass with Bias
        h1 = np.mean(brain.W_in[ids], axis=0).reshape(1, -1)
        z2 = np.dot(h1, brain.W_h) + brain.b_h
        h2 = relu(z2)
        logits = (np.dot(h2, brain.W_out) + brain.b_out)[0]
        
        # Repetition Penalty (Stronger)
        counts = Counter(generated_ids)
        for wid, count in counts.items():
            logits[wid] -= (pen_base + count * pen_inc)

        # N-gram Penalty
        if len(generated_ids) >= 2:
            for n in range(2, 5):
                if len(generated_ids) < n: continue
                last_ngram = tuple(generated_ids[-n:])
                for i in range(len(generated_ids) - n):
                    if last_ngram == tuple(generated_ids[i:i+n]):
                        logits[last_ngram[-1]] -= 30.0
                        break

        # TF-IDF Boost
        if brain.tfidf:
            for idx in range(len(logits)):
                word = brain.i2w.get(idx, '')
                logits[idx] += brain.tfidf.get(word, 0) * 0.05

        # Sampling
        logits = np.nan_to_num(logits, nan=-10.0)
        exp_logits = np.exp((logits - np.max(logits)) / temp)
        probs = exp_logits / (np.sum(exp_logits) + 1e-9)
        
        # Top-P
        sorted_idx = np.argsort(probs)[::-1]
        cum_probs = np.cumsum(probs[sorted_idx])
        cutoff = np.where(cum_probs >= top_p)[0]
        if len(cutoff) > 0:
            probs[sorted_idx[cutoff[0]+1:]] = 0
        probs /= (np.sum(probs) + 1e-9)
        
        try:
            next_id = np.random.choice(len(probs), p=probs)
        except:
            next_id = np.argmax(logits)
            
        word = brain.i2w.get(next_id, '<unk>')
        if word == ".": break
        res_text.append(word)
        generated_ids.append(next_id)
        
        ids.append(next_id)
        if len(ids) > context_window: ids.pop(0)
        
    return " ".join(res_text) + "."
