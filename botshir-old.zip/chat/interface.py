from chat.engine import mars_generate
import os

def start_chat(brain, cfg):
    data_file = cfg['paths']['data_file']
    project_name = cfg['project']['name']
    print(f"[{project_name} Online. Type 'exit' to quit]")
    
    while True:
        try:
            inp = input("You: ").lower().strip()
            if not inp or inp == 'exit': break
            
            with open(data_file, "a", encoding="utf-8") as f:
                # Sử dụng os.linesep để tránh lỗi ký tự xuống dòng trong chuỗi
                f.write(inp + " ." + os.linesep)
            
            words = inp.split()
            brain.expand(words)
            
            # Kiểm tra bộ não theo kiến trúc mới
            if brain.W_in.size == 0:
                print("AI: Please train me first.")
                continue
            
            response = mars_generate(brain, words, cfg)
            print("AI: " + response)
            
        except KeyboardInterrupt: break
    
    brain.save()
    print("[!] Knowledge saved. Goodbye!")
